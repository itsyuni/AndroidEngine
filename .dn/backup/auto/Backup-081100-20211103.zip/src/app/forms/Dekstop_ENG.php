<?php
namespace app\forms;

use php\gui\framework\AbstractForm;
use php\gui\event\UXMouseEvent; 
use php\gui\event\UXEvent; 


class Dekstop_ENG extends AbstractForm
{

    /**
     * @event image7.click-Left 
     */
    function doImage7ClickLeft(UXMouseEvent $event = null)
    {    
        
    }

    /**
     * @event image8.click-Left 
     */
    function doImage8ClickLeft(UXMouseEvent $event = null)
    {    
        
    }

    /**
     * @event image9.click-Left 
     */
    function doImage9ClickLeft(UXMouseEvent $event = null)
    {    
        
    }

    /**
     * @event image10.click-Left 
     */
    function doImage10ClickLeft(UXMouseEvent $event = null)
    {    
        
    }

    /**
     * @event image6.mouseUp-Left 
     */
    function doImage6MouseUpLeft(UXMouseEvent $event = null)
    {    
        
    }

    /**
     * @event button.click-Left 
     */
    function doButtonClickLeft(UXMouseEvent $event = null)
    {    
        
    }

    /**
     * @event buttonAlt.click-Left 
     */
    function doButtonAltClickLeft(UXMouseEvent $event = null)
    {    
        
    }

    /**
     * @event construct 
     */
    function doConstruct(UXEvent $event = null)
    {    
        
    }

    /**
     * @event image11.click-Left 
     */
    function doImage11ClickLeft(UXMouseEvent $event = null)
    {    
        
    }

}
