<?php
namespace app\forms;

use php\gui\framework\AbstractForm;
use php\gui\event\UXMouseEvent; 


class Sms extends AbstractForm
{

    /**
     * @event image4.click-Left 
     */
    function doImage4ClickLeft(UXMouseEvent $event = null)
    {    
        
    }



}
