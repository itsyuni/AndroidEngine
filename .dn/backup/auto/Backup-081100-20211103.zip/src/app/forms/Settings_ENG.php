<?php
namespace app\forms;

use php\gui\framework\AbstractForm;
use php\gui\event\UXMouseEvent; 


class Settings_ENG extends AbstractForm
{

    /**
     * @event button.click-Left 
     */
    function doButtonClickLeft(UXMouseEvent $event = null)
    {    
        
    }

    /**
     * @event buttonAlt.click-Left 
     */
    function doButtonAltClickLeft(UXMouseEvent $event = null)
    {    
        
    }


    /**
     * @event label4.click-Left 
     */
    function doLabel4ClickLeft(UXMouseEvent $event = null)
    {    
        
    }

    /**
     * @event label5.click-Left 
     */
    function doLabel5ClickLeft(UXMouseEvent $event = null)
    {    
        
    }

    /**
     * @event label13.click-Left 
     */
    function doLabel13ClickLeft(UXMouseEvent $event = null)
    {    
        
    }

    /**
     * @event label6.click-Left 
     */
    function doLabel6ClickLeft(UXMouseEvent $event = null)
    {    
        
    }

    /**
     * @event label7.click-Left 
     */
    function doLabel7ClickLeft(UXMouseEvent $event = null)
    {    
        
    }

    /**
     * @event label9.mouseDown-Left 
     */
    function doLabel9MouseDownLeft(UXMouseEvent $event = null)
    {    
        
    }

    /**
     * @event label11.click-Left 
     */
    function doLabel11ClickLeft(UXMouseEvent $event = null)
    {    
        
    }


}
